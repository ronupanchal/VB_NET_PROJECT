NOTE:  L-nix is packaged in this archive using Info-ZIP's compression
utility.  The installation program uses UnZip to read zip files from the
archive file.  Info-ZIP's software (Zip, UnZip and related utilities) is
free and can be obtained as source code or executables from various
bulletin board services and anonymous-ftp sites, including CompuServe's
IBMPRO forum and ftp.uu.net:/pub/archiving/zip/*.
______________________________________________________________________

To install the L-nix program simply type a: then install if using the
L-nix diskette or install if installing from a hard disk.

To start the L-nix tutorial, at the DOS prompt type the name of drive
you installed to, then change into the LX directory and then type LX to
start.  For example:

C:
CD \LX 
LX

You may switch to the UNIX shell simulation at any point in the L-nix
program by hitting ALT S (that is, press down the ALT key while at the 
same time hitting the S key).  To return back to the tutorial hit ALT S
once more.

Please read the file L-nix.txt for instructions on using the L-nix tutorial.

