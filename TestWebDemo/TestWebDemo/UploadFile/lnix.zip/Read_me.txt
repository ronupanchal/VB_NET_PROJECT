L-nix v1.20a is an interactive UNIX tutorial for MS DOS, Windows users may 
run L-nix from a DOS window.  At any point in the tutorial, the user may 
easily switch over to a UNIX shell simulation.  In the shell, users may 
try out most of the commands covered in the tutorial screens.  Being 
merely a simulation, the shell is very limited in what can be done 
there. Users can, however, get a feel for the UNIX environment by
trying out commands here.  In many modules, after a certain amount of
material has been covered in the tutorial, a short multiple choice test
can be taken.  The testing is entirely optional, the user may skip it at
any time. 

Special requirements: None.  
Changes: Address info changed.
Shareware, freely distributable.  Uploaded by the author.  
Run setup.bat file to install.

Michael Fullerton
CyberMatrix Corp.
support@cyber-matrix.com
